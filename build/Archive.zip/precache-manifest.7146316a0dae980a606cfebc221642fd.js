self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d3041f557c555d7aa1830f720b261881",
    "url": "/index.html"
  },
  {
    "revision": "5956f124e72438393f08",
    "url": "/static/css/2.cfae0931.chunk.css"
  },
  {
    "revision": "6e8fe30e3197568f7c1d",
    "url": "/static/css/main.027c62a1.chunk.css"
  },
  {
    "revision": "5956f124e72438393f08",
    "url": "/static/js/2.6382ada4.chunk.js"
  },
  {
    "revision": "e92648ff5a80d087520aac2854794ec7",
    "url": "/static/js/2.6382ada4.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6e8fe30e3197568f7c1d",
    "url": "/static/js/main.8cd51eb7.chunk.js"
  },
  {
    "revision": "c443f59de6f441f9a599",
    "url": "/static/js/runtime-main.9c88bc3e.js"
  },
  {
    "revision": "00e482bd9c464cb3bc64db1e5144eac8",
    "url": "/static/media/logo.00e482bd.svg"
  },
  {
    "revision": "6b3893da264682e43581a9a8205600fc",
    "url": "/static/media/w-logo.6b3893da.png"
  }
]);